# -*- coding: utf-8 -*-
"""
Created on Thu Oct 21 13:04:01 2021

@author: Sverre
@author: Hanna
"""

import random as rand
import time as time
from tkinter import *
import os
from PIL import Image, ImageTk
import cv2
import numpy as np
from ffpyplayer.player import MediaPlayer

import RPi.GPIO as GPIO # Import Raspberry Pi GPIO library
GPIO.setmode(GPIO.BOARD)
GPIO.setup(8, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(7, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.add_event_detect(8, GPIO.RISING) 
GPIO.add_event_detect(7, GPIO.RISING)
  
# setter grunn-widget som alt legges i
root = Tk()
# legger tittel til vinduet
root.title("Nytt på nytt")
# setter grunn-widgeten til størrelse på skjerm
root.geometry("2560x1600")

# lager en ny grunn-widget, til stor skjerm
root2 = Toplevel() 
# legger tittel til vinduet
root.title("Nytt på nytt")
# setter størrelse til størrelse på skjerm
root2.geometry("1920x1080")

# lager canvas til liten skjerm
canvas_main = Canvas(root)
# legger canvas inn og gjør at det fyller hele skjermen
canvas_main.pack(fill = "both", expand = YES)

# lager canvas til stor skjermen
canvas_main2 = Canvas(root2)
# legger canvas inn og gjør at det fyller hele skjermen
canvas_main2.pack(fill = "both", expand = YES)

# legger inn bakgrunnsbilde-fil til liten skjerm
bg = Image.open("nytt_pa_nytt_sett1.jpg")
# endrer bakgrunnsbildet til skjermstørrelse
bg = bg.resize((2560, 1600), Image.ANTIALIAS) 
bg = ImageTk.PhotoImage(bg)
bg_label = Label(image=bg)
bg_label.image = bg

# legger inn bildefil, bakgrunnsbilde til stor skjerm
bg2 = Image.open("nytt_pa_nytt_sett1.jpg")
bg2 = bg2.resize((1920, 1080), Image.ANTIALIAS) # endrer bakgrunnsbildet til skjermstørrelse
bg2 = ImageTk.PhotoImage(bg2)
bg2_label = Label(image=bg2)
bg2_label.image = bg2

def skjerm(s,person):
    # SKJERM 1
    # viser bakgrunnsbildet
    canvas_main.create_image(0, 0, image = bg, anchor = "nw")
    
    # legger til instruksjon 
    canvas_main.create_text(1280, 100, text=f"Hva tror du {person} har sagt?", font=('Arial', 80, "bold"), fill="white") 
    canvas_main.create_text(1280, 200, text="Klikk på tilhørende knapp!", font=("Arial", 60), fill="white")

    # lager canvas til utsagnene 
    canvas_quotes = Canvas(canvas_main, width=2360, height=1200, bg="#ff920d")
    # plasserer canvas
    canvas_quotes.place(x=100, y=300)

    # utsagn 1
    canvas_quotes.create_text(1180, 300,  text=spørsmål[s][0], font=("Arial", 90), fill="white", width=2160)
    # utsagn 2
    canvas_quotes.create_text(1180, 900,  text=spørsmål[s][1], font=("Arial", 90), fill="white", width=2160)

    # oppdaterer root kontinuerlig
    root.update()
    
    
    # SKJERM 2
    canvas_main2.create_image(0, 0, image = bg2, anchor = "nw")

    # legger til instruksjon
    canvas_main2.create_text(960, 100, text=f"Hva tror du {person} har sagt?", font=('Arial', 50, "bold"), fill="white") 
    canvas_main2.create_text(960, 170, text=f"Klikk på tilhørende knapp!", font=("Arial", 45), fill="white")

    # lager canvas til utsagnene
    canvas_quotes2 = Canvas(canvas_main2, width=1620, height=700, bg="#ff920d")
    # plasserer canvas
    canvas_quotes2.place(x=150, y=240)

    # utsagn 1
    canvas_quotes2.create_text(810, 200,  text=spørsmål[s][0], font=("Arial", 45), fill="white", width=1420)
    # utsagn 2
    canvas_quotes2.create_text(810, 500,  text=spørsmål[s][1], font=("Arial", 45), fill="white", width=1420)

    # oppdaterer root2 kontinuerlig
    root2.update()

spørsmål = [
    ["Pinlig stemning på Guantanamo","Skjønner ikke hva de klager over, det var mye verre i konsentrasjonsleirer før",0,1,"guantanamo_redigert.mp4"],
    ["Vi er sånn derre si-det-rett-fra-levra. Hæstkuk-folk.", "De har det tross alt litt bedre enn sånne bardehvaler som har magen full av plastbestikk",1 , 2, "bardehvaler_redigert.mp4"],
    ["Fordømte innvandrere, kan de ikke integrere seg og bli sånn som oss!", "Egentlig kan man vaske alt med oppvaskmiddel og ei gammel underbukse.",0,0,"fordomte_innvandrere_redigert.mp4"],
    ["Har du mistet bakkekontakten helt etter at du forlot NRK, Jon?", "Det er så slitsomt hvis vi må forklare deg alle vitsene Jon",1,2, "forklare_vitser_redigert.mp4"],
    ["Det å lære om fred og vennskap i verden, det er det satan sjøl som arrangerer","Det er jo det samme som i 1939 å skulle ha barbert bort barten til Hitler.",0,2, "fred_og_vennskap_redigert.mp4"],
    ["Vi kan dø hele tiden. Taket her kan falle ned i hodet på oss nå. Det hadde blitt en spesiell sending, men det kan skje. ", "Men det sier noe om landet vårt, at når vi setter inn heimeværnet for første gang i fredstid så er det for å hente folk fra hytta",1,1,"heimevernet_i_fredtid_redigert.mp4"],
    ["Du må kunne tåle å bli kalt 'fittekjerring' og 'hore' en gang eller to i lunsjen når det blir gjort med glimt i øyet", "Juhuu! Det var på tide. Jeg er dritt lei de gamle. Sars, fulgeinfluensa... Endelig har vi noe nytt. Corona det er digg.", 0, 2, "hore_og_fittekjerring_redigert.mp4"],
    ["Det er bedre å være en litt sprø kjedelig fyr, enn å være en kjedelig sprøing", "Det viser seg at hvis to er uenige, så er det veldig mye lettere å komme til enighet hvis den ene ikke er til stede",1,1,  "lettere_enighet_redigert.mp4"],
    ["Jeg driter i om jeg får narkotika eller en artig nøkkelring","Kan revolusjon i Norge starte fordi yoghurten til Tine har treskjeer?", 0,1, "narkotika_eller_nokkelring_redigert.mp4"],
    ["Alle som har sett en hvilken som helst katastrofefilm vet at det er den koko professoren som får rett til slutt ", "Sånn går det når man ikke vil inngå kompromiss, da blir resultatet vagina", 1, 2, "resultatet_vagina_redigert.mp4"],
    ["Jeg er ikke redd, vi har jo Sjaman Durek","Det kan være lurt med en liten epidemi", 0, 1, "sjaman_durek_redigert.mp4"],
    ["Her har det vært guttastemning!","HIV",0,1, "vaert_guttastemning_redigert.mp4"],
]
programledere = ['Bård','Johan','Pernille']

def spørre():
    knapp = 0
    global q
    q = rand.randint(0,len(spørsmål)-1)
    person = programledere[spørsmål[q][3]]
    s=q
    skjerm(s,person)
    
    while True:
        time.sleep(0.01)
        
        if GPIO.event_detected(7):
            knapp = 0
            break
        if GPIO.event_detected(8):
            knapp = 1
            break
    return knapp

def teste_svar(q,svar):
    if svar == spørsmål[q][2]:
        test = 1
    else:
        test = 0
    return test

def PlayVideo(correct_video):
    video=cv2.VideoCapture(correct_video)
    player = MediaPlayer(correct_video)
    while True:
        grabbed, frame=video.read()
        audio_frame, val = player.get_frame()
        if not grabbed:
            break
        if cv2.waitKey(28) & 0xFF == ord("q"):
            break
        cv2.imshow("Video", frame)
        if val != 'eof' and audio_frame is not None:
            #audio
            img, t = audio_frame
    video.release()
    cv2.destroyAllWindows()


while len(spørsmål) > 0:
    s = spørre()
    test = teste_svar(q,s)

    canvas_quotes = Canvas(canvas_main, width=2360, height=1200, bg="#ff920d")
    canvas_quotes.place(x=100, y=300)
    
    canvas_quotes2 = Canvas(canvas_main2, width=1620, height=700, bg="#ff920d")
    canvas_quotes2.place(x=150, y=240)
    
    if test == 1:
        canvas_quotes.create_text(1180, 300,  text='Riktig svar!', font=("Arial", 110), fill="white", width=2160)
        canvas_quotes2.create_text(810, 200,  text='Riktig svar!', font=("Arial", 45), fill="white", width=1420)
    else:
        canvas_quotes.create_text(1180, 300,  text='Feil svar!', font=("Arial", 110), fill="white", width=2160)
        canvas_quotes2.create_text(810, 200,  text='Feil svar!', font=("Arial", 45), fill="white", width=1420)
    root.update()
    root2.update()
    
    time.sleep(2)
    PlayVideo(spørsmål[q][4])
    
    spørsmål.pop(q)
    while True:
        time.sleep(0.01)
        if GPIO.event_detected(7):
            break
        if GPIO.event_detected(8):
            break
        
    